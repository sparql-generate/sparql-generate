package com.github.thesmartenergy;

import be.ugent.mmlab.rml.core.RMLEngine;
import be.ugent.mmlab.rml.core.StdRMLEngine;
import be.ugent.mmlab.rml.mapdochandler.extraction.std.StdRMLMappingFactory;
import be.ugent.mmlab.rml.mapdochandler.retrieval.RMLDocRetrieval;
import be.ugent.mmlab.rml.model.RMLMapping;
import be.ugent.mmlab.rml.model.dataset.RMLDataset;
import be.ugent.mmlab.rml.model.dataset.StdRMLDataset;
import com.github.thesmartenergy.sparql.generate.jena.SPARQLGenerate;
import com.github.thesmartenergy.sparql.generate.jena.engine.PlanFactory;
import com.github.thesmartenergy.sparql.generate.jena.engine.RootPlan;
import com.github.thesmartenergy.sparql.generate.jena.query.SPARQLGenerateQuery;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import org.apache.commons.io.IOUtils;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.riot.RDFDataMgr;
import org.apache.jena.util.Locator;
import org.apache.jena.util.LocatorFile;
import org.apache.jena.util.FileManager;
import org.apache.jena.util.LocationMapper;
import org.openrdf.repository.Repository;
import org.openrdf.rio.RDFFormat;

public class Main {

    private static int nb_iter = 1;
    private static int[] sizes = {100, 1000, 5000};
    private static String[] queries = {"simple"};
    private static String[] languages = {"SPARQL-Generate", "RML"};

    public static void main(String[] args) throws Exception {
        URI base = Main.class.getClassLoader().getResource("").toURI();
        System.out.println(base.toURL());

        FileWriter fw = new FileWriter("results.txt", false);

        for (int size : sizes) {
            for (String query : queries) {
                for (String language : languages) {
                    long[] data = new long[nb_iter];
                    for (int i = 0; i < nb_iter; i++) {
                        switch (language) {
                            case "RML":
                                data[i] = testRML(base, size, query + ".ttl");
                                break;
                            case "SPARQL-Generate":
                                data[i] = testSPARQLGenerate(base, size, query + ".rqg");
                                break;
                        }
                    }
                    Statistics stats = new Statistics(data);
                    //System.out.println(Math.round(stats.getMean()) + " ( +- " + Math.round(stats.getStdDev()) + ")");
                    String result = size + " - " + query + " - " + language + " -> " + Math.round(stats.getMean()) + " ( +- " + Math.round(stats.getStdDev()) + ")";
                    System.out.println(result);
                    fw.write(result + "\n");
                    fw.flush();
                }
            }
        }
        
        fw.close();
    }


    

    public static long testSPARQLGenerate(URI base, int size, String queryName) throws URISyntaxException, IOException {

        // get plan factory 
        String path = size + "/persons.csv";
        String personFileUri = "http://example.org/persons" + size + ".csv";
        FileManager fileManager = getFileManager(base, path, personFileUri);
        PlanFactory factory = new PlanFactory(fileManager);

        // get query
        String query = IOUtils.toString(new FileReader("target/classes/queries/" + queryName));
        query = query.replaceAll("XXXpersons", personFileUri);

        SPARQLGenerateQuery q = (SPARQLGenerateQuery) QueryFactory.create(query, SPARQLGenerate.SYNTAX);

        // create plan for query
        long t1 = System.currentTimeMillis();
        RootPlan plan = factory.create(q);
        long t2 = System.currentTimeMillis();
        System.out.println("CREATE PLAN TIME " + (t2 - t1));        
        // execute plan
        t1 = System.currentTimeMillis();
        Model output = plan.exec();
        t2 = System.currentTimeMillis();

        if(size==100) {
            output.write(System.out,"TTL");
        }
        return t2 - t1;
    }
    
    
    private static FileManager getFileManager(URI base, String path, String personFileUri) throws MalformedURLException {
        Model conf = ModelFactory.createDefaultModel();
        Resource mapping = conf.createResource();
        Resource personMapping = conf.createResource();
        conf.add(mapping, conf.createProperty("http://jena.hpl.hp.com/2004/08/location-mapping#mapping"), personMapping);
        conf.add(personMapping, conf.createProperty("http://jena.hpl.hp.com/2004/08/location-mapping#name"), personFileUri);
        conf.add(personMapping, conf.createProperty("http://jena.hpl.hp.com/2004/08/location-mapping#altName"), path);

        FileManager fileManager = FileManager.makeGlobal();
        Locator loc = new LocatorFile(base.toURL().toString());
        LocationMapper mapper = new LocationMapper(conf);
        fileManager.addLocator(loc);
        fileManager.setLocationMapper(mapper);
        return fileManager;
    }

    

    public static long testRML(URI base, int size, String queryName) throws FileNotFoundException, MalformedURLException {
        String outputFormat = "turtle";
        String graphName = "";
        String pathToRMLFile = base.resolve("queries/" + queryName).toURL().toString();
        String pathToAugmentedRMLFile = "mapping.ttl";

        Model conf = RDFDataMgr.loadModel(pathToRMLFile);

        Resource subject = conf.createResource();
        conf.add(conf.getResource("http://example.org/#PersonMapping"), conf.createProperty("http://semweb.mmlab.be/ns/rml#logicalSource"), subject);
        conf.add(subject, conf.createProperty("http://semweb.mmlab.be/ns/rml#source"), "target/classes/" + size + "/persons.csv");
        conf.add(subject, conf.createProperty("http://semweb.mmlab.be/ns/rml#referenceFormulation"), conf.createResource("http://semweb.mmlab.be/ns/ql#CSV"));

        conf.write(new FileOutputStream(pathToAugmentedRMLFile), "Turtle");

        StdRMLMappingFactory mappingFactory = new StdRMLMappingFactory();

        RMLDocRetrieval mapDocRetrieval = new RMLDocRetrieval();
        Repository repository = mapDocRetrieval.getMappingDoc(pathToAugmentedRMLFile, RDFFormat.TURTLE);

        long t1 = System.currentTimeMillis();
        RMLMapping mapping = mappingFactory.extractRMLMapping(repository);
        long t2 = System.currentTimeMillis();
        System.out.println("EXTRACT MAPPING TIME " + (t2 - t1));

        RMLEngine engine = new StdRMLEngine();
        t1 = System.currentTimeMillis();
        RMLDataset output = engine.runRMLMapping(new StdRMLDataset(), mapping, "http://example.com", null, null);
       
//        engine.run(mapping, graphName, parameters, queries)un(mapping, null, outputFormat, graphName, null, null, null, null, null);
        t2 = System.currentTimeMillis();

        if(size == 100) {
            output.dumpRDF(System.out, RDFFormat.TURTLE);        
        }
        return t2 - t1;
    }

    static class Statistics {

        long[] data;
        double size;

        public Statistics(long[] data) {
            this.data = data;
            size = data.length;
        }

        double getMean() {
            double sum = 0.0;
            for (double a : data) {
                sum += a;
            }
            return sum / size;
        }

        double getVariance() {
            double mean = getMean();
            double temp = 0;
            for (double a : data) {
                temp += (mean - a) * (mean - a);
            }
            return temp / size;
        }

        double getStdDev() {
            return Math.sqrt(getVariance());
        }

    }

}
