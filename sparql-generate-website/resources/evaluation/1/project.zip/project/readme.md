# Instructions to reproduce the experiment:


## Download and install RMLMapper

- git clone --recursive https://github.com/RMLio/RML-Mapper.git
- git submodule update --init --recursive
- git submodule foreach --recursive git checkout master
- mvn install -DskipTests

## Download and install `sparql-generate-jena`

This is automatically done by Maven.

## Documents

- download https://w3id.org/sparql-generate/evaluation/1/documents.zip
- unzip its content into `src\main\resources`

## Run

- choose the sizes and number of iterations to test in class `com.github.thesmartenergy.Main`
- build the project using maven: `mvn install`
- run class `com.github.thesmartenergy.Main`

## Results

Raw results are written in file `results.txt` at in the root directory of the project.